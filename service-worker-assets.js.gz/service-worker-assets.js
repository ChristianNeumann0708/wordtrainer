self.assetsManifest = {
  "version": "1vBmGU+i",
  "assets": [
    {
      "hash": "sha256-9o5G8nmjL/Wr8q4VNpqZgSBAuFo3JNEAeQrEcR3nqlY=",
      "url": "WordTrainer.Pwa.styles.css"
    },
    {
      "hash": "sha256-NplgXTj9dtAkuv02Ux8t6QFxjZlpWzNy3ng0yBOkTjA=",
      "url": "_framework/Microsoft.AspNetCore.Components.2hlikighgk.wasm"
    },
    {
      "hash": "sha256-9HVWE0vHBox1LBcSOAIDS/tvKOK6AVzr1yvDzDbJYNE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.si5g68dp8b.wasm"
    },
    {
      "hash": "sha256-5W/dEZqTcxDqupVA/p+oJXEUoeyodSlu8xQhv/Ql9f0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.z2zmt6eh6c.wasm"
    },
    {
      "hash": "sha256-DF5ZQPnsimHgu/OhXI14ihBGcEBOY9jXNikZbJl7ouk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gdtptxu0m1.wasm"
    },
    {
      "hash": "sha256-WQurBbuDtkPNdWdC7Lbk07OTfLLaEGN9l68/4BxEU7c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3ped9ou2lc.wasm"
    },
    {
      "hash": "sha256-W7mtMnscYp8Lm6bOFiNQIzi2jmhPwTSt+p55NOguXJk=",
      "url": "_framework/Microsoft.Extensions.Configuration.rg826fsozh.wasm"
    },
    {
      "hash": "sha256-eugn1mUEty9xpv1pG+j1s4wSrtDGxui5xJChc2FyXY0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.q8c22zx6cf.wasm"
    },
    {
      "hash": "sha256-rEG3da6BrNUeO3KbBWBg2CeOLGPbwAhaeQkynbC3XMQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.scyrntte5w.wasm"
    },
    {
      "hash": "sha256-IwHLEJOKi6cFRe+dXSUvsVF4dX+OJRiASgaf/aNlPZQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.beqi3qigp0.wasm"
    },
    {
      "hash": "sha256-Qa4/Z0kdUZSeM/AH6VqMRzUW+WiiYzKP4SfIVpkTH3M=",
      "url": "_framework/Microsoft.Extensions.Logging.vgeqi1hit2.wasm"
    },
    {
      "hash": "sha256-qZf+8bXdS5Ra82sUMZVQAIqye4YDc/4f+4VzhFevuh4=",
      "url": "_framework/Microsoft.Extensions.Options.xmn8i3fd0s.wasm"
    },
    {
      "hash": "sha256-2nwt/yCgkPWTWOYu9vIkVJmV0x+uCHRFb2VTrQRVD5w=",
      "url": "_framework/Microsoft.Extensions.Primitives.eui7srgduq.wasm"
    },
    {
      "hash": "sha256-4I+0kHd4SomBH7+AYwAomyTpYchOHG0eb6kHl9ZrDTk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0o8pok1eno.wasm"
    },
    {
      "hash": "sha256-+NFEC87ZBXwGVzoScrnTurAScmo/GbQ1EAM9ZYHqGPY=",
      "url": "_framework/Microsoft.JSInterop.kt5e9h7bdn.wasm"
    },
    {
      "hash": "sha256-1otcN3kaKoiuzBSmFij2dR1cbGaPloslrvqpAe8zEqQ=",
      "url": "_framework/System.Collections.Concurrent.m1nahsorkc.wasm"
    },
    {
      "hash": "sha256-S7GqOJm/8VEXqCpRlA3If3vDjdC2o7aXhWghifN29aQ=",
      "url": "_framework/System.Collections.Immutable.ffyc02j4ty.wasm"
    },
    {
      "hash": "sha256-RBikKY9spy8FIX1d3tcsgJXKLPCPZFSec2/uMAp34AY=",
      "url": "_framework/System.Collections.kwrc4br715.wasm"
    },
    {
      "hash": "sha256-hh9IFXL/RbhfSsmIpjQd2JKV0syxfT/lZ8Wx1o36oAE=",
      "url": "_framework/System.ComponentModel.u61y5gga6s.wasm"
    },
    {
      "hash": "sha256-a8tqeuYfoiWZ05o/HwJw03L5d2cdvz0LVHQpz2ZOHf8=",
      "url": "_framework/System.Console.t2zc0egktf.wasm"
    },
    {
      "hash": "sha256-ybi3iTFv6n/oJez9DrGFSd+3vF/0EM6LQhUqDi/Y3ds=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.vqbfy78wfb.wasm"
    },
    {
      "hash": "sha256-YETgkYsSCpN1j8iN/kykAr/xvo1Wj21YdTdxzCtB1LQ=",
      "url": "_framework/System.IO.Pipelines.4f8vg2rcxi.wasm"
    },
    {
      "hash": "sha256-rBo2gbuAKuDvNFg4LLbNttct+NG4HjYv1apRc2NjopQ=",
      "url": "_framework/System.Linq.ceprw79wwm.wasm"
    },
    {
      "hash": "sha256-oHkidPOv9VkEnu+RgI/tN26O0/4PwIlS0CKWJutQOHs=",
      "url": "_framework/System.Memory.8eqo23ju8j.wasm"
    },
    {
      "hash": "sha256-PghJmX89o6JPu1AJvEgi3/wvbTQDHEy0LCICrpXHiW4=",
      "url": "_framework/System.Net.Http.666onnery4.wasm"
    },
    {
      "hash": "sha256-Pbi0bOhF1Zd4r/RnDBDw88zKh+dEVhP2icASOjjeVTU=",
      "url": "_framework/System.Net.Primitives.dswx0h3u76.wasm"
    },
    {
      "hash": "sha256-DVGBai+0rHUiq77GLVrBB3D+Q7stm8lfXBBKPgkdcmI=",
      "url": "_framework/System.Private.CoreLib.959fd2st1g.wasm"
    },
    {
      "hash": "sha256-YQcepZIQB8W/+GNrxv2QwHxD+ON2Epqxb6oxpyQIasc=",
      "url": "_framework/System.Private.Uri.3bpul22u77.wasm"
    },
    {
      "hash": "sha256-06lcyxHxg8ToEYAV9xVWWXf+2+2A36BLPbV1tu/iYuo=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lanx20edgb.wasm"
    },
    {
      "hash": "sha256-x29PTYtGo808o0PG7Uk7Drpj8lkScpyjO3jsYEYqK48=",
      "url": "_framework/System.Runtime.n4ut63szc7.wasm"
    },
    {
      "hash": "sha256-2moma+Q/JRBY6Q172/lkRsN7/ZJ4sSFm1DFbCKsVvJs=",
      "url": "_framework/System.Security.Cryptography.yyjjz7spvh.wasm"
    },
    {
      "hash": "sha256-Z7mHCBaA/tB8qPOsWxva+7TO2egvfezD7deZN0XRRmI=",
      "url": "_framework/System.Text.Encodings.Web.rf7vel8nja.wasm"
    },
    {
      "hash": "sha256-wkifJS8jDzHk5pumpEbdEHOu94iMOSeqjrDdK4RkMJI=",
      "url": "_framework/System.Text.Json.qd58asjiy0.wasm"
    },
    {
      "hash": "sha256-DVYKhwn+nCtYFF7t9kkzTsEwAqx8JVKdn1IjNpKncD8=",
      "url": "_framework/System.Text.RegularExpressions.hj9f8s4pgu.wasm"
    },
    {
      "hash": "sha256-JSmumu4BoDbc/hEnPJTSG8x6/ziHym5S2Hr6L2hw3w4=",
      "url": "_framework/WordTrainer.Pwa.zqljqq2z4g.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-AeYeTsO63URlnrWOsKe2AJPiJBejQD/4DPXBmynJ5vs=",
      "url": "_framework/dotnet.9m6i877cyl.js"
    },
    {
      "hash": "sha256-/I3SDHIle7heAxlUGBrgxax+lkKyWyRLBVEJmTHJSCs=",
      "url": "_framework/dotnet.native.cs8mcre4gh.js"
    },
    {
      "hash": "sha256-vjddPOzSD1RO9Een4QrlAPnxzBSmD/QchBKKmBMLZwg=",
      "url": "_framework/dotnet.native.muve7a13r4.wasm"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-8LljOBK09yh+wCg90hg97bHqU9fSO2d3Ng049JIyBCY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-GVxnbJejFYQj4JH3e8+duFXwnPTkycfwYoHYofRd0cA=",
      "url": "icons/icon-192.png"
    },
    {
      "hash": "sha256-rAnrPbF4KovO/yusnEGAzLO/BaENniF2oOeQ82l3EME=",
      "url": "icons/icon-512.png"
    },
    {
      "hash": "sha256-3UYBFkXsXlartZjb3gDp5anI3ril+haSkdEV9Zgr14I=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-FsiHTQEG0Ro6yC1aZzXsrxQcJo29+KWD1P5uiM8cDU0=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-vybzwzPtciyqdcsRkXzLJQurJuiDd6YBs2RriB0mUOE=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-6hI/e2/VTDvL29Ww/UK42zl5YtbbcikjI4JgHfGzP/w=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-b99YALtFayMEyuwZX0gIc+as4gHz3HkdXyABeVI4f28=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-jOyjxmUclJaSXaMfneDzUVJFNvBL0RiNHL9E7eV0NWg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-KZt1IP7zYByENDu4yFzRPtl6kPr+5N1fHMP87hXzX4I=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-gTJrkhxIyaxAZZlWECyaNHdk0DyTJizBANTUoWdxfUg=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-/Vxmn1kmT3brO1mk2/eIZvHJkn4HQcyHWUp89ZwbFrY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-dB5Dkc1vYhhB8/UodoSW0IRV/uXQZVnJegARtaWipF4=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-wg3VAvNP1VTwGzVKZ6RpbpeTcpmG+bmuzhyPtLHwscU=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
